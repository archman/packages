# -*- coding: utf-8 -*-

import logging

def disable_warnings(level=60):
    logging.disable(level)
